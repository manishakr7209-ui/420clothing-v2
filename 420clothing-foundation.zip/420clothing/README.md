# 420Clothing — Project Foundation

A production-ready **foundation** for a premium men's clothing e-commerce
platform. This is a monorepo containing a Next.js frontend and an
Express/TypeScript backend, connected to PostgreSQL via Prisma.

> **Scope note:** This is Phase 2 — the project foundation only. There is
> intentionally **no business logic, no database tables, no real
> authentication, and no product pages yet**. Every folder and file here
> exists to give the next phases a clean, scalable structure to build
> into. See `docs/architecture.md` for the full reasoning behind every
> decision.

## Monorepo Layout

```
420clothing/
├── frontend/     Next.js 15 app (customer storefront + admin panel)
├── backend/      Express + TypeScript API
├── docs/         Architecture & setup documentation
└── package.json  Root workspace scripts
```

## Tech Stack

| Layer          | Choice                                   |
|----------------|-------------------------------------------|
| Frontend       | Next.js 15 (App Router), React, TypeScript, Tailwind CSS, Framer Motion |
| Backend        | Node.js, Express.js, TypeScript          |
| Database       | PostgreSQL + Prisma ORM                  |
| Authentication | JWT + bcrypt (structure only for now)    |
| Image Storage  | Cloudinary                               |
| Deployment     | Frontend → Vercel · Backend → Railway    |

## Quick Start

### 1. Install dependencies

```bash
# From the repo root (installs both workspaces)
npm install

# Or individually
cd frontend && npm install
cd ../backend && npm install
```

### 2. Configure environment variables

```bash
cp frontend/.env.example frontend/.env.local
cp backend/.env.example backend/.env
```

Fill in real values — see `docs/environment-variables.md` for what each
one does.

### 3. Set up the database

```bash
cd backend
npx prisma generate
# npx prisma migrate dev   ← run once real models exist (Phase 3)
```

### 4. Run both apps in development

```bash
# From repo root, in two terminals:
npm run dev:backend    # http://localhost:5000
npm run dev:frontend   # http://localhost:3000
```

## Documentation

- [`docs/architecture.md`](./docs/architecture.md) — why every folder and package exists
- [`docs/frontend-backend-communication.md`](./docs/frontend-backend-communication.md) — how the two apps talk to each other
- [`docs/authentication-plan.md`](./docs/authentication-plan.md) — how auth *will* work once implemented
- [`docs/deployment.md`](./docs/deployment.md) — how deployment to Vercel + Railway works
- [`docs/git-workflow.md`](./docs/git-workflow.md) — branching strategy & first commit instructions
- [`docs/design-system.md`](./docs/design-system.md) — the visual design system (colors, type, components)

## What's Deliberately NOT Here Yet

Per the Phase 2 brief, the following are out of scope until later phases:

- Prisma data models (User, Product, Order, etc.)
- Real authentication logic (login/register handlers, token issuing)
- Product listing/detail business logic
- Cart, checkout, and payment logic
- Admin CRUD functionality

Everything above already has a designated folder and, in the backend, a
placeholder route returning `501 Not Implemented` — so wiring in real
logic later means *filling in* files, not restructuring the app.
