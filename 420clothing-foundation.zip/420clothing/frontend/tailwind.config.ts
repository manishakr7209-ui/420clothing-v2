/**
 * tailwind.config.ts
 * ────────────────────────────────────────────────────────────
 * 420Clothing Design System — token source of truth.
 *
 * Design direction: heritage tailoring house, not "startup fashion app".
 * Palette is built around ink (near-black), bone (warm off-white), and a
 * brass accent (evokes hardware on outerwear — buttons, buckles, zip
 * pulls) with a deep burgundy reserved for rare emphasis (sale, alerts).
 * All colors are exposed as CSS variables in globals.css so dark/light
 * mode is a variable swap, not a duplicated palette.
 */
import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        // Semantic tokens — components should reference THESE, not raw hexes.
        ink: "rgb(var(--color-ink) / <alpha-value>)",           // primary text / near-black surfaces
        bone: "rgb(var(--color-bone) / <alpha-value>)",         // primary background (warm off-white)
        surface: "rgb(var(--color-surface) / <alpha-value>)",   // cards / panels
        border: "rgb(var(--color-border) / <alpha-value>)",
        brass: "rgb(var(--color-brass) / <alpha-value>)",       // primary accent (CTAs, active states)
        "brass-dark": "rgb(var(--color-brass-dark) / <alpha-value>)",
        burgundy: "rgb(var(--color-burgundy) / <alpha-value>)", // sale / destructive-adjacent emphasis
        muted: "rgb(var(--color-muted) / <alpha-value>)",       // secondary text
        success: "rgb(var(--color-success) / <alpha-value>)",
        danger: "rgb(var(--color-danger) / <alpha-value>)",
        warning: "rgb(var(--color-warning) / <alpha-value>)",
      },
      fontFamily: {
        // Display: warm tailored serif for headings & hero moments.
        display: ["var(--font-display)", "Georgia", "serif"],
        // Body/UI: clean grotesque sans for legibility at small sizes.
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        // Utility: monospace for prices, SKUs, order numbers — reads like a garment tag.
        mono: ["var(--font-mono)", "monospace"],
      },
      fontSize: {
        // Fluid-ish premium type scale (rem-based, generous line-height for editorial feel)
        xs: ["0.75rem", { lineHeight: "1.4" }],
        sm: ["0.875rem", { lineHeight: "1.5" }],
        base: ["1rem", { lineHeight: "1.6" }],
        lg: ["1.125rem", { lineHeight: "1.6" }],
        xl: ["1.375rem", { lineHeight: "1.5" }],
        "2xl": ["1.75rem", { lineHeight: "1.3" }],
        "3xl": ["2.25rem", { lineHeight: "1.2" }],
        "4xl": ["3rem", { lineHeight: "1.1" }],
        "5xl": ["4rem", { lineHeight: "1.05" }],
        "6xl": ["5.5rem", { lineHeight: "1" }],
      },
      spacing: {
        // 4px base unit, extended for generous editorial whitespace
        18: "4.5rem",
        22: "5.5rem",
        30: "7.5rem",
      },
      borderRadius: {
        sm: "2px",
        DEFAULT: "4px",
        md: "6px",
        lg: "10px",
        // Deliberately restrained — sharp-ish corners read "tailored", not "app".
      },
      boxShadow: {
        card: "0 1px 2px rgb(0 0 0 / 0.04), 0 8px 24px -8px rgb(0 0 0 / 0.12)",
        elevated: "0 4px 8px rgb(0 0 0 / 0.06), 0 16px 40px -12px rgb(0 0 0 / 0.18)",
      },
      transitionTimingFunction: {
        signature: "cubic-bezier(0.22, 1, 0.36, 1)", // used for premium ease-out motion
      },
      keyframes: {
        "fade-in": { from: { opacity: "0" }, to: { opacity: "1" } },
        "slide-up": {
          from: { opacity: "0", transform: "translateY(8px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        "fade-in": "fade-in 0.4s cubic-bezier(0.22, 1, 0.36, 1) forwards",
        "slide-up": "slide-up 0.5s cubic-bezier(0.22, 1, 0.36, 1) forwards",
      },
    },
  },
  plugins: [],
};

export default config;
