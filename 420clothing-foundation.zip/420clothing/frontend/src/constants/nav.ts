/**
 * constants/nav.ts
 * Central place for route path strings, so the app never hardcodes
 * "/shop" etc. in multiple components — change once, update everywhere.
 */
export const ROUTES = {
  home: "/",
  shop: "/shop",
  product: (slug: string) => `/product/${slug}`,
  cart: "/cart",
  wishlist: "/wishlist",
  checkout: "/checkout",
  profile: "/profile",
  orders: "/orders",
  login: "/login",
  register: "/register",
  admin: {
    dashboard: "/admin/dashboard",
    products: "/admin/products",
    orders: "/admin/orders",
    customers: "/admin/customers",
    inventory: "/admin/inventory",
    analytics: "/admin/analytics",
    settings: "/admin/settings",
  },
} as const;
