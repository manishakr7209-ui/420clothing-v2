/**
 * lib/utils.ts
 * Shared helper: merges Tailwind classes safely (handles conflicts
 * like "p-2 p-4" -> keeps only the last one). Used by every UI component.
 */
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
