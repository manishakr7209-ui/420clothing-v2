/**
 * lib/api.ts
 * ────────────────────────────────────────────────────────────
 * Single Axios instance the whole frontend uses to talk to the
 * backend. Centralizing this means:
 *   - one base URL (from env) instead of hardcoded strings everywhere
 *   - one place to attach auth headers / refresh-token interceptors later
 *   - one place to handle global error shapes from apiResponse.ts (backend)
 *
 * NOTE: interceptors for attaching JWT access tokens will be added
 * once auth is implemented (Phase 3) — structure only for now.
 */
import axios from "axios";

export const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
  withCredentials: true, // sends the httpOnly refresh-token cookie
  headers: { "Content-Type": "application/json" },
});
