# Store (Zustand)

Client-side global state (cart contents, wishlist, UI toggles) will live
here as small, focused Zustand stores — e.g. `cart.store.ts`,
`wishlist.store.ts`. Kept empty in Phase 2 since no cart/wishlist logic
exists yet; the folder exists so state management has an obvious home
once that logic is built.
