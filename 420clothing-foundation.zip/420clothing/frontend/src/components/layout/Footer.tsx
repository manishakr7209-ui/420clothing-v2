/**
 * components/layout/Footer.tsx
 * Site-wide footer — link columns + brand line. Static content only.
 */
import Link from "next/link";

const COLUMNS = [
  {
    title: "Shop",
    links: [
      { href: "/shop", label: "All Products" },
      { href: "/shop?category=new", label: "New Arrivals" },
      { href: "/shop?category=sale", label: "Sale" },
    ],
  },
  {
    title: "Support",
    links: [
      { href: "/orders", label: "Track Order" },
      { href: "/profile", label: "My Account" },
      { href: "#", label: "Shipping & Returns" },
    ],
  },
  {
    title: "Company",
    links: [
      { href: "#", label: "Our Story" },
      { href: "#", label: "Sustainability" },
      { href: "#", label: "Careers" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-border bg-ink text-bone">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <span className="font-display text-2xl">
              420<span className="text-brass">Clothing</span>
            </span>
            <p className="mt-3 text-sm text-bone/60">
              Tailored menswear, built to last.
            </p>
          </div>
          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h4 className="font-mono text-xs uppercase tracking-wider text-brass">{col.title}</h4>
              <ul className="mt-4 space-y-2">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link href={link.href} className="text-sm text-bone/70 hover:text-bone">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 border-t border-bone/10 pt-6 text-xs text-bone/50">
          © {new Date().getFullYear()} 420Clothing. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
