/**
 * components/layout/Navbar.tsx
 * Top navigation — sticky, shows primary shop nav + cart/wishlist/
 * account icons. Uses only structure/design-system tokens; no
 * cart-count or auth state wired up yet (Phase 2 = foundation only).
 */
"use client";

import Link from "next/link";
import { Heart, Menu, Search, ShoppingBag, User } from "lucide-react";
import { useState } from "react";

const NAV_LINKS = [
  { href: "/shop", label: "Shop" },
  { href: "/shop?category=outerwear", label: "Outerwear" },
  { href: "/shop?category=tailoring", label: "Tailoring" },
  { href: "/shop?category=accessories", label: "Accessories" },
];

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bone/95 backdrop-blur">
      <div className="mx-auto flex h-18 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <button
          className="lg:hidden"
          aria-label="Toggle menu"
          onClick={() => setMobileOpen((v) => !v)}
        >
          <Menu className="h-5 w-5" />
        </button>

        <Link href="/" className="font-display text-2xl tracking-tight text-ink">
          420<span className="text-brass">Clothing</span>
        </Link>

        <nav className="hidden gap-8 lg:flex">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm tracking-wide text-ink/80 transition-colors hover:text-brass"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-5">
          <button aria-label="Search" className="text-ink/80 hover:text-brass">
            <Search className="h-5 w-5" />
          </button>
          <Link href="/wishlist" aria-label="Wishlist" className="text-ink/80 hover:text-brass">
            <Heart className="h-5 w-5" />
          </Link>
          <Link href="/cart" aria-label="Cart" className="text-ink/80 hover:text-brass">
            <ShoppingBag className="h-5 w-5" />
          </Link>
          <Link href="/login" aria-label="Account" className="text-ink/80 hover:text-brass">
            <User className="h-5 w-5" />
          </Link>
        </div>
      </div>

      {mobileOpen && (
        <nav className="flex flex-col gap-1 border-t border-border px-4 py-3 lg:hidden">
          {NAV_LINKS.map((link) => (
            <Link key={link.href} href={link.href} className="py-2 text-sm text-ink/80">
              {link.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
