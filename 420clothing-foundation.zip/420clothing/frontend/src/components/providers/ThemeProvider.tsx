/**
 * components/providers/ThemeProvider.tsx
 * Wraps next-themes to power light/dark mode via the `.dark` class
 * that globals.css's CSS variables key off of.
 */
"use client";

import { ThemeProvider as NextThemesProvider } from "next-themes";
import { ReactNode } from "react";

export function ThemeProvider({ children }: { children: ReactNode }) {
  return (
    <NextThemesProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
      {children}
    </NextThemesProvider>
  );
}
