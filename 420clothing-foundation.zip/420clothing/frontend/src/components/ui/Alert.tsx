/**
 * components/ui/Alert.tsx
 * Inline banner for form/page-level messages (not toasts).
 */
import { HTMLAttributes } from "react";
import { AlertTriangle, CheckCircle2, Info, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";

type Tone = "info" | "success" | "warning" | "danger";

interface AlertProps extends HTMLAttributes<HTMLDivElement> {
  tone?: Tone;
  title?: string;
}

const icons: Record<Tone, typeof Info> = {
  info: Info,
  success: CheckCircle2,
  warning: AlertTriangle,
  danger: XCircle,
};

const toneStyles: Record<Tone, string> = {
  info: "border-border bg-surface text-ink",
  success: "border-success/30 bg-success/10 text-success",
  warning: "border-warning/30 bg-warning/10 text-warning",
  danger: "border-danger/30 bg-danger/10 text-danger",
};

export function Alert({ className, tone = "info", title, children, ...props }: AlertProps) {
  const Icon = icons[tone];
  return (
    <div className={cn("flex gap-3 rounded border p-4 text-sm", toneStyles[tone], className)} {...props}>
      <Icon className="mt-0.5 h-4 w-4 shrink-0" />
      <div>
        {title && <p className="font-medium">{title}</p>}
        <div className="text-ink/80">{children}</div>
      </div>
    </div>
  );
}
