/**
 * components/ui/Skeleton.tsx
 * Loading placeholder block, used by loading.tsx route files.
 */
import { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Skeleton({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("animate-pulse rounded bg-border/60", className)} {...props} />;
}
