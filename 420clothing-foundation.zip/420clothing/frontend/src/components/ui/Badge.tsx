/**
 * components/ui/Badge.tsx
 * Small status label — reads like a garment hang-tag. Used for
 * "New", "Sale", order statuses, stock levels, etc.
 */
import { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Tone = "neutral" | "brass" | "success" | "danger" | "warning";

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  tone?: Tone;
}

const toneStyles: Record<Tone, string> = {
  neutral: "bg-border/60 text-ink",
  brass: "bg-brass/15 text-brass-dark",
  success: "bg-success/15 text-success",
  danger: "bg-danger/15 text-danger",
  warning: "bg-warning/15 text-warning",
};

export function Badge({ className, tone = "neutral", ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-sm px-2 py-0.5 font-mono text-xs uppercase tracking-wider",
        toneStyles[tone],
        className
      )}
      {...props}
    />
  );
}
