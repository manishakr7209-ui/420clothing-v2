/**
 * components/ui/Button.tsx
 * Core button — variants map directly to design-system tokens.
 * "primary" = brass (main CTA), "outline" = ink border on bone,
 * "ghost" = text-only for low-emphasis actions, "destructive" = burgundy.
 */
import { ButtonHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "outline" | "ghost" | "destructive";
type Size = "sm" | "md" | "lg";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

const variantStyles: Record<Variant, string> = {
  primary: "bg-brass text-ink hover:bg-brass-dark",
  outline: "border border-ink text-ink hover:bg-ink hover:text-bone",
  ghost: "text-ink hover:bg-surface",
  destructive: "bg-burgundy text-bone hover:opacity-90",
};

const sizeStyles: Record<Size, string> = {
  sm: "h-9 px-3 text-sm",
  md: "h-11 px-5 text-sm",
  lg: "h-13 px-7 text-base",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "md", ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "inline-flex items-center justify-center gap-2 rounded font-sans font-medium tracking-wide transition-colors duration-200 ease-signature disabled:pointer-events-none disabled:opacity-50",
          variantStyles[variant],
          sizeStyles[size],
          className
        )}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";
