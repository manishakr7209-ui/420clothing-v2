/**
 * config/site.ts
 * Site-wide metadata/config constants (name, description, socials).
 */
export const siteConfig = {
  name: "420Clothing",
  description: "Premium men's clothing, tailored to last.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
};
