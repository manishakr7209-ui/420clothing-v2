/**
 * app/loading.tsx
 * Root-level suspense fallback shown during route transitions.
 */
import { Skeleton } from "@/components/ui";

export default function Loading() {
  return (
    <div className="mx-auto max-w-7xl space-y-4 px-4 py-16">
      <Skeleton className="h-8 w-1/3" />
      <Skeleton className="h-64 w-full" />
    </div>
  );
}
