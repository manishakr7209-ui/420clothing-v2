/**
 * app/(shop)/layout.tsx
 * Layout for all customer-facing storefront routes (shop, product,
 * cart, wishlist, checkout). A route group "(shop)" so the URL
 * has no /shop-group segment, but they all share Navbar + Footer.
 */
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";

export default function ShopLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navbar />
      <main className="min-h-[60vh]">{children}</main>
      <Footer />
    </>
  );
}
