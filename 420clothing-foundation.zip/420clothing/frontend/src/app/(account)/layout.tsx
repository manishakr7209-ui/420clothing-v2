/**
 * app/(account)/layout.tsx
 * Layout for authenticated customer-account routes (profile, orders).
 * Shares the same storefront shell for now; a route-level auth guard
 * (redirect to /login if unauthenticated) is added once auth exists.
 */
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";

export default function AccountLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navbar />
      <main className="mx-auto min-h-[60vh] max-w-5xl px-4 py-10">{children}</main>
      <Footer />
    </>
  );
}
