/**
 * app/page.tsx — Home route "/"
 * Placeholder hero only (per Phase 2 scope: no product/business logic yet).
 */
export default function HomePage() {
  return (
    <main className="mx-auto flex min-h-[70vh] max-w-7xl flex-col items-center justify-center px-4 text-center">
      <span className="font-mono text-xs uppercase tracking-widest text-brass">
        Foundation Build — Phase 2
      </span>
      <h1 className="mt-4 font-display text-5xl text-ink sm:text-6xl">
        420<span className="text-brass">Clothing</span>
      </h1>
      <p className="mt-4 max-w-lg text-muted">
        The project scaffolding is live. Product, cart, and checkout logic arrive in later phases.
      </p>
    </main>
  );
}
