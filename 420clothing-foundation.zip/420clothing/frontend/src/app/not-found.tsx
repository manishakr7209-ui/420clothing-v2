/**
 * app/not-found.tsx
 * Global 404 — shown for any unmatched route.
 */
import Link from "next/link";
import { Button } from "@/components/ui";

export default function NotFound() {
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center gap-4 px-4 text-center">
      <span className="font-mono text-sm uppercase tracking-widest text-brass">404</span>
      <h1 className="font-display text-4xl text-ink">This page isn&apos;t in stock.</h1>
      <p className="max-w-md text-sm text-muted">
        The page you&apos;re looking for doesn&apos;t exist or has been moved.
      </p>
      <Link href="/">
        <Button>Back to Home</Button>
      </Link>
    </div>
  );
}
