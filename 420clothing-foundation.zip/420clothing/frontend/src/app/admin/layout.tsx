/**
 * app/admin/layout.tsx
 * Distinct app shell for the admin panel — sidebar navigation
 * instead of the storefront Navbar/Footer. A route-level guard
 * (restrict to ADMIN role) plugs in here once auth exists.
 */
import { AdminSidebar } from "@/components/layout/AdminSidebar";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-bone">
      <AdminSidebar />
      <main className="flex-1 p-6 lg:p-10">{children}</main>
    </div>
  );
}
