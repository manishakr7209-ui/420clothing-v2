/**
 * app/admin/dashboard/page.tsx
 * Placeholder admin route — structure only, no business logic yet (Phase 2 scope).
 */
export default function Page() {
  return (
    <div>
      <h1 className="font-display text-2xl text-ink">Dashboard</h1>
      <p className="mt-2 text-sm text-muted">This admin route is scaffolded and ready for Phase 3+ logic.</p>
    </div>
  );
}
