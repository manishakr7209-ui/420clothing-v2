/**
 * app/error.tsx
 * Root error boundary — catches uncaught rendering/data errors
 * anywhere in the tree and shows a recovery UI instead of a blank page.
 */
"use client";

import { Button } from "@/components/ui";

export default function Error({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 px-4 text-center">
      <h1 className="font-display text-3xl text-ink">Something went off the rack.</h1>
      <p className="max-w-md text-sm text-muted">
        An unexpected error occurred. You can try again, or head back to the homepage.
      </p>
      <Button onClick={() => reset()}>Try again</Button>
    </div>
  );
}
