/**
 * app/(auth)/layout.tsx
 * Minimal, distraction-free shell for login/register — deliberately
 * excludes Navbar/Footer so the auth flow stays focused.
 */
export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-bone px-4">
      <div className="w-full max-w-sm">{children}</div>
    </div>
  );
}
