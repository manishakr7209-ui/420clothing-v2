/**
 * app/layout.tsx
 * ────────────────────────────────────────────────────────────
 * Root layout — wraps EVERY route. Loads fonts, sets up
 * ThemeProvider (dark/light), and injects global CSS.
 * Navbar/Footer are NOT included here because /admin uses a
 * different shell (AdminSidebar) — see app/(shop)/layout.tsx
 * and app/admin/layout.tsx instead.
 */
import type { Metadata } from "next";
import { Fraunces, Inter, IBM_Plex_Mono } from "next/font/google";
import { ThemeProvider } from "@/components/providers/ThemeProvider";
import "@/styles/globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const plexMono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "420Clothing — Tailored Menswear",
  description: "Premium men's clothing, built to last.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${fraunces.variable} ${inter.variable} ${plexMono.variable}`}>
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
