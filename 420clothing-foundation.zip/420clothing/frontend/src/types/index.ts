/**
 * types/index.ts
 * Shared frontend TypeScript types. Domain types (Product, Order, User)
 * will be added once the database schema (Phase 3) defines their shape —
 * ideally generated/mirrored from the Prisma schema to avoid drift.
 */
export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data?: T;
  errors?: unknown;
}
