# How the Backend Talks to the Database

> No tables exist yet (that's Phase 3). This explains the *pipeline*
> that will carry data once they do.

## The pipeline

```
Repository function (e.g. findUserByEmail)
        │
        ▼
Prisma Client  (backend/src/config/database.ts)
        │  translates the function call into SQL
        ▼
PostgreSQL database
```

## Why Prisma

Prisma is an ORM (Object-Relational Mapper) that lets the backend
describe data models in `prisma/schema.prisma` using a simple syntax,
then generates a fully-typed client (`@prisma/client`). Benefits:

- **Type safety** — if a model field is renamed, TypeScript immediately
  flags every place in the code that breaks, instead of failing silently
  at runtime.
- **Migrations** — `prisma migrate dev` turns schema changes into
  versioned SQL migration files, so the whole team's databases (and
  production) can be updated in a repeatable, trackable way.
- **No raw SQL required** for typical queries, while still allowing raw
  SQL (`prisma.$queryRaw`) for anything complex.

## Why a singleton Prisma Client (`config/database.ts`)

In development, Next.js/`tsx watch`-style hot reloading can re-execute
module code on every file save. If a `new PrismaClient()` were created
inside a route handler, each reload would open a new database
connection without closing the old one, quickly exhausting PostgreSQL's
connection limit. `config/database.ts` creates **one** client and
reuses it across reloads (via a global variable in development).

## Why only `repositories/` may import Prisma

This is a deliberate rule, not a technical limitation. Keeping all
`prisma.*` calls inside `repositories/` means:

- Services stay focused on business rules, not query syntax.
- If the ORM or database technology ever changes, only `repositories/`
  needs to be touched.
- Repositories can be swapped for mocks in unit tests without spinning
  up a real database.

## What Phase 3 will add here

- `prisma/schema.prisma` — the actual `User`, `Product`, `Category`,
  `Order`, `OrderItem`, `Cart`, `Review`, etc. models.
- `repositories/*.repository.ts` — typed functions like
  `findUserByEmail()`, `createOrder()`.
- `prisma migrate dev` run to create the real PostgreSQL tables.
