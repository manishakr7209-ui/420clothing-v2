# Routing Reference

Next.js App Router: a file's path under `frontend/src/app/` IS the URL.
Folders in parentheses, like `(shop)`, are **route groups** — they
organize files and share a layout without appearing in the URL.

| URL | File | Layout used |
|---|---|---|
| `/` | `app/page.tsx` | Root layout only |
| `/shop` | `app/(shop)/shop/page.tsx` | Storefront (Navbar + Footer) |
| `/product/[slug]` | `app/(shop)/product/[slug]/page.tsx` | Storefront |
| `/cart` | `app/(shop)/cart/page.tsx` | Storefront |
| `/wishlist` | `app/(shop)/wishlist/page.tsx` | Storefront |
| `/checkout` | `app/(shop)/checkout/page.tsx` | Storefront |
| `/profile` | `app/(account)/profile/page.tsx` | Storefront (account variant) |
| `/orders` | `app/(account)/orders/page.tsx` | Storefront (account variant) |
| `/login` | `app/(auth)/login/page.tsx` | Minimal auth shell |
| `/register` | `app/(auth)/register/page.tsx` | Minimal auth shell |
| `/admin/dashboard` | `app/admin/dashboard/page.tsx` | Admin (sidebar) |
| `/admin/products` | `app/admin/products/page.tsx` | Admin |
| `/admin/orders` | `app/admin/orders/page.tsx` | Admin |
| `/admin/customers` | `app/admin/customers/page.tsx` | Admin |
| `/admin/inventory` | `app/admin/inventory/page.tsx` | Admin |
| `/admin/analytics` | `app/admin/analytics/page.tsx` | Admin |
| `/admin/settings` | `app/admin/settings/page.tsx` | Admin |

Every page above currently renders a placeholder — the route, layout,
and design-system wiring are in place so Phase 3+ only needs to add
real content, not restructure the app.

## Backend route versioning

All API routes are mounted under `/api/v1/...` (see
`backend/src/routes/v1/index.ts`). Currently registered resource
routers — each returns `501 Not Implemented` until real handlers exist:

- `/api/v1/auth/*`
- `/api/v1/users/*`
- `/api/v1/products/*`
- `/api/v1/orders/*`

Plus a health check at `GET /health` (unversioned, used by deployment
platforms to verify the server is alive).
