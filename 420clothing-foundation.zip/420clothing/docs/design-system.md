# Design System

A premium, tailoring-house aesthetic — not a generic SaaS-app look.
Every token lives in `frontend/src/styles/globals.css` (CSS variables)
and `frontend/tailwind.config.ts` (Tailwind mapping), so changing a
color or font touches **one file**, not every component.

## Palette

| Token | Light mode | Role |
|---|---|---|
| `ink` | `#14110F` (near-black) | Primary text, dark-mode background |
| `bone` | `#F3EFE6` (warm off-white) | Primary background |
| `surface` | `#FFFFFF` | Cards, panels, inputs |
| `border` | `#DCD5C7` | Dividers, outlines |
| `brass` | `#A6873F` | Primary accent — CTAs, active states, focus rings |
| `burgundy` | `#6B1D24` | Reserved emphasis — sale badges, rare destructive-adjacent actions |
| `muted` | `#6F675C` | Secondary text |
| `success` / `danger` / `warning` | green / red / amber | Status feedback |

The brass accent was chosen to evoke hardware on outerwear — buttons,
buckles, zip pulls — rather than the generic warm-cream-and-terracotta
palette common in AI-generated designs. Burgundy is used sparingly, by
design, so it retains impact when it appears (sale tags, low-stock
warnings).

Dark mode isn't a dimmed copy of light mode — it inverts the ink/bone
relationship (ink becomes the background, bone becomes the text), so
both modes feel intentionally designed rather than auto-generated.

## Typography

| Role | Typeface | Used for |
|---|---|---|
| Display | Fraunces (serif) | Headings, hero text — warm, tailored, editorial |
| Body / UI | Inter (sans) | Paragraphs, buttons, form fields — clean and legible at small sizes |
| Utility | IBM Plex Mono | Prices, SKUs, order numbers, badges — reads like a garment tag |

Type scale runs from `text-xs` (12px) to `text-6xl` (88px) with
generous line-heights for an editorial, unhurried feel — see
`tailwind.config.ts` → `theme.extend.fontSize`.

## Spacing & shape

- Base spacing unit is Tailwind's default 4px scale, extended with
  `18`, `22`, `30` (72px/88px/120px) for generous section padding.
- Border radius is deliberately restrained (`2px`–`10px`) — sharp-ish
  corners read as "tailored," not "consumer app."
- Two shadow levels: `shadow-card` (subtle, for product cards) and
  `shadow-elevated` (for modals/dropdowns).

## Motion

Framer Motion is used for the `Modal` component (fade + scale-up
entrance) and two reusable Tailwind animation utilities
(`animate-fade-in`, `animate-slide-up`) for page-load reveals. All
motion respects `prefers-reduced-motion` (see `globals.css`).

## Components (`components/ui/`)

| Component | Notes |
|---|---|
| `Button` | Variants: `primary` (brass), `outline`, `ghost`, `destructive` (burgundy) |
| `Card` | Composable: `Card`, `CardHeader`, `CardBody`, `CardFooter` |
| `Input` | Label + error message slots built in |
| `Select` | Styled native `<select>` |
| `Badge` | Monospace, uppercase — used for status/stock/sale tags |
| `Alert` | Inline banner, 4 tones (info/success/warning/danger) |
| `Modal` | Framer Motion enter/exit, Escape-to-close, focus-friendly |
| `Table` | `Table`, `Thead`, `Th`, `Td` — used throughout `/admin` |
| `Skeleton` | Pulse-loading placeholder, used in `loading.tsx` files |

## Dark mode

Powered by `next-themes` (`components/providers/ThemeProvider.tsx`),
toggled via `components/shared/ThemeToggle.tsx`. Adding `.dark` to
`<html>` swaps every CSS variable in `globals.css` — no component code
needs to know which mode is active.

## Icons

`lucide-react` — a single consistent icon set, sized at `h-4 w-4` /
`h-5 w-5` throughout for visual consistency.
