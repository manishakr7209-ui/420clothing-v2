# Deployment

The frontend and backend deploy **independently** to two platforms, each
chosen for what it's best at.

## Frontend → Vercel

1. Push the repo to GitHub.
2. In Vercel: "Add New Project" → import the repo.
3. Set the **Root Directory** to `frontend` (important — this is a
   monorepo, so Vercel needs to know where the Next.js app lives).
4. Add environment variables from `frontend/.env.example` in the Vercel
   project settings (Production + Preview).
5. Vercel auto-detects Next.js and deploys on every push to `main`
   (production) and every PR (preview deployment with its own URL).

Why Vercel: it's built by the Next.js team, gives automatic preview URLs
per pull request, edge caching, and zero-config image optimization.

## Backend → Railway

1. In Railway: "New Project" → "Deploy from GitHub repo".
2. Set the **Root Directory** to `backend`.
3. Add a **PostgreSQL** plugin from Railway's marketplace — it
   auto-generates a `DATABASE_URL` you plug into the backend's env vars.
4. Add the remaining environment variables from `backend/.env.example`.
5. Set the **Build Command** to `npm run build` and the **Start Command**
   to `npm run start` (these run `tsc` then `node dist/server.js`).
6. Railway assigns a public URL (e.g. `https://420clothing-api.up.railway.app`) —
   put that in the frontend's `NEXT_PUBLIC_API_URL`.

Why Railway: simple managed PostgreSQL alongside the API in one
dashboard, straightforward pricing, and none of the cold-start latency
that serverless functions would add to a stateful Express app with a
persistent DB connection pool.

## Connecting the two in production

- Backend's `FRONTEND_URL` env var = the Vercel production URL (used by
  `config/cors.ts` to allow requests from it).
- Frontend's `NEXT_PUBLIC_API_URL` env var = the Railway backend URL +
  `/api/v1`.
- Both platforms support automatic redeploys on every push to `main`,
  so shipping a change is just `git push`.

## Environments

| Environment | Frontend | Backend | Database |
|---|---|---|---|
| Local dev | `localhost:3000` | `localhost:5000` | Local Postgres or a Railway dev DB |
| Preview (per PR) | Vercel preview URL | *(shares a staging Railway backend, or run locally)* | Staging DB |
| Production | Vercel production domain | Railway production URL | Railway production Postgres |
