# Architecture & Folder Reference

This document explains **why** every folder exists and **why** every
package was installed. Written for someone new to full-stack projects.

## 1. Why a monorepo?

`frontend/` and `backend/` live in one repository with a root
`package.json` using npm **workspaces**. Benefits at this stage:

- One `git clone` gets the whole project.
- Root-level scripts (`npm run dev:frontend`) without `cd`-ing around.
- Still fully independent deployments — Vercel only looks at `frontend/`,
  Railway only looks at `backend/`.

If the team grows significantly, splitting into separate repos is a
later option, not a Phase 2 concern.

## 2. Backend folder-by-folder

```
backend/
├── prisma/
│   └── schema.prisma        Database connection + (future) models
├── src/
│   ├── server.ts             Starts the HTTP server (the only file that calls .listen())
│   ├── app.ts                Builds the Express app: middleware + routes
│   ├── config/                Environment/service configuration
│   │   ├── env.ts             Validates process.env with Zod — fails fast on missing vars
│   │   ├── cors.ts            Which frontend origins may call this API
│   │   ├── database.ts        Singleton Prisma Client
│   │   └── cloudinary.ts      Cloudinary SDK configuration
│   ├── routes/                Express routers — URL → handler mapping only
│   │   └── v1/                 Versioned API (/api/v1/...) so v2 can exist later without breaking v1 clients
│   ├── controllers/           HTTP layer: reads req, calls a service, sends a response
│   ├── services/              Business logic — the actual rules of the app
│   ├── repositories/          The ONLY layer allowed to import Prisma — all DB queries live here
│   ├── middleware/            Cross-cutting request handling (auth, errors, rate limiting, validation)
│   ├── validations/           Zod schemas describing valid request shapes
│   ├── errors/                Custom error classes (AppError, NotFoundError, etc.)
│   ├── utils/                 Logger, JWT helpers, password hashing, response formatting
│   └── types/                 Shared TypeScript types (e.g. Express Request augmentation)
```

### Why this many layers? (Controller → Service → Repository)

This is the **Repository Pattern** combined with a classic **layered
architecture**. Each layer has exactly one job:

1. **Route** — "which URL maps to which function?"
2. **Controller** — "read the HTTP request, call the right service, send
   the HTTP response." No business rules here.
3. **Service** — "what are the actual rules?" (e.g. "an order can't ship
   without a valid address"). No `req`/`res` here — services don't know
   they're being called over HTTP, which makes them reusable (e.g. from
   a background job) and easy to unit test.
4. **Repository** — "how do I fetch/save this in the database?" Only
   this layer imports Prisma. If the database technology ever changed,
   only this folder would need to change.

A request flows **down** the stack and a response flows back **up**:
`route → controller → service → repository → database`, then the result
bubbles back up to the controller, which sends the JSON response.

### Why `middleware/errorHandler.middleware.ts` matters

Instead of every controller wrapping its logic in `try/catch` and
formatting error JSON by hand, controllers just `throw` a typed error
(e.g. `throw new NotFoundError("Product not found")`). The
`asyncHandler` wrapper catches the rejected promise and forwards it to
`errorHandler`, which is the **single place** that decides what error
JSON looks like. This keeps error formatting consistent across every
endpoint in the app.

### Why `config/env.ts` uses Zod

`process.env` values are always `string | undefined` in TypeScript,
which invites bugs (a missing `JWT_ACCESS_SECRET` failing silently at
3am in production). `env.ts` validates every variable at startup — the
server refuses to boot if a required variable is missing or malformed,
which is far easier to debug than a mysterious runtime crash later.

## 3. Frontend folder-by-folder

```
frontend/src/
├── app/                        Next.js App Router — folder structure = URL structure
│   ├── (shop)/                  Route GROUP: shares the storefront Navbar/Footer shell
│   │   ├── shop/                 /shop
│   │   ├── product/[slug]/       /product/my-product-slug (dynamic route)
│   │   ├── cart/                 /cart
│   │   ├── wishlist/             /wishlist
│   │   └── checkout/             /checkout
│   ├── (account)/               Route GROUP: authenticated customer pages
│   │   ├── profile/              /profile
│   │   └── orders/                /orders
│   ├── (auth)/                  Route GROUP: login/register, minimal shell (no Navbar/Footer)
│   ├── admin/                   /admin/* — separate app shell (AdminSidebar, not Navbar)
│   ├── layout.tsx                Root layout — fonts, ThemeProvider, global CSS
│   ├── page.tsx                  Home page "/"
│   ├── loading.tsx               Root loading fallback (Suspense)
│   ├── error.tsx                 Root error boundary
│   └── not-found.tsx             Global 404 page
├── components/
│   ├── ui/                       Design-system primitives (Button, Card, Input, Modal, ...)
│   ├── layout/                   Navbar, Footer, AdminSidebar — structural, app-wide components
│   ├── shared/                   Reusable components that aren't pure UI primitives (e.g. ThemeToggle)
│   └── providers/                React context providers (ThemeProvider, and later CartProvider etc.)
├── lib/                          Framework-agnostic helpers (cn(), the Axios `api` instance)
├── hooks/                        Reusable React hooks
├── store/                        Zustand global state (empty until cart/wishlist logic exists)
├── types/                        Shared TypeScript types
├── constants/                    Route path constants, etc.
├── config/                       Site-wide config (name, description, URL)
└── styles/                       globals.css — design tokens (CSS variables) + base styles
```

### Why "route groups" like `(shop)` and `(auth)`?

Parentheses around a folder name — `(shop)` — tell Next.js "organize
routes here, but don't add this to the URL." This lets different parts
of the app share **different layouts** without changing any URLs:

- `(shop)` and `(account)` both render inside the storefront layout
  (`Navbar` + `Footer`).
- `(auth)` renders inside a minimal, distraction-free layout — no
  Navbar/Footer — better UX for login/register.
- `admin/` (no parentheses, since `/admin` IS a real URL prefix) renders
  inside a completely different shell (`AdminSidebar`).

### Why the Repository/Service split doesn't exist on the frontend

The frontend's job is presentation and calling the API — it doesn't
talk to a database directly, so it doesn't need a repository layer. Its
equivalent structure is `lib/api.ts` (the one place HTTP calls to the
backend originate from) and, in later phases, `store/` (client state)
plus custom hooks per feature (e.g. `useCart()`).

## 4. Why each package was installed

### Backend

| Package | Why |
|---|---|
| `express` | The HTTP server framework itself |
| `@prisma/client` + `prisma` | Type-safe database access and migrations |
| `bcrypt` | Hashes passwords — never store plaintext passwords |
| `jsonwebtoken` | Issues/verifies JWTs for authentication |
| `cors` | Restricts which frontend origins can call the API |
| `helmet` | Sets secure HTTP headers by default |
| `compression` | Gzips responses for faster load times |
| `cookie-parser` | Reads the httpOnly refresh-token cookie |
| `dotenv` | Loads `.env` into `process.env` in development |
| `zod` | Runtime validation for env vars and request bodies |
| `winston` + `morgan` | Structured application logging + HTTP request logging |
| `express-rate-limit` | Throttles requests to prevent abuse/brute-force |
| `cloudinary` | SDK for uploading/serving product images |
| `multer` | Parses `multipart/form-data` for file uploads |
| `tsx` | Runs TypeScript directly in dev with hot reload |
| `typescript`, `@types/*` | Type safety and editor autocomplete |
| `eslint`, `prettier` | Code quality and consistent formatting |

### Frontend

| Package | Why |
|---|---|
| `next`, `react`, `react-dom` | The framework itself |
| `typescript` | Type safety across the app |
| `tailwindcss`, `postcss`, `autoprefixer` | Utility-first styling + CSS vendor prefixing |
| `framer-motion` | Animations (page transitions, modals, micro-interactions) |
| `zustand` | Lightweight global state (cart, wishlist, UI toggles) |
| `clsx` + `tailwind-merge` | Safely combine conditional Tailwind classes without conflicts |
| `lucide-react` | Icon set used throughout the UI |
| `zod` | Client-side form/data validation, shared "shape" language with the backend |
| `axios` | HTTP client for calling the backend API |
| `next-themes` | Light/dark mode toggling |
| `eslint-config-next` | Next.js-specific lint rules |
| `prettier-plugin-tailwindcss` | Auto-sorts Tailwind classes for consistency |
