# Authentication Plan (Not Yet Implemented)

> Per Phase 2 scope, no login/register logic exists yet. This document
> explains the structure already in place and how it will be filled in.

## What already exists (structure only)

| File | Purpose |
|---|---|
| `backend/src/utils/password.ts` | `hashPassword()` / `comparePassword()` using bcrypt |
| `backend/src/utils/jwt.ts` | `signAccessToken()`, `signRefreshToken()`, `verify*Token()` |
| `backend/src/middleware/auth.middleware.ts` | `protect()` and `restrictTo(...roles)` — currently pass-through stubs |
| `backend/src/routes/v1/auth.routes.ts` | Placeholder route returning `501 Not Implemented` |
| `frontend/src/app/(auth)/login`, `.../register` | Placeholder pages with a dedicated minimal layout |

## How it will work once implemented (Phase 3+)

1. **Register** — `POST /api/v1/auth/register` — validate input with a
   Zod schema (`validations/auth.validation.ts`), hash the password with
   `hashPassword()`, save the user via `user.repository.ts`.
2. **Login** — `POST /api/v1/auth/login` — verify credentials with
   `comparePassword()`, issue:
   - a short-lived **access token** (returned in the JSON response body,
     stored in memory on the frontend — never `localStorage`, to reduce
     XSS risk), and
   - a long-lived **refresh token** (set as an `httpOnly` secure cookie,
     invisible to JavaScript).
3. **Authenticated requests** — the frontend sends the access token in
   an `Authorization: Bearer <token>` header. `middleware/auth.middleware.ts`'s
   `protect()` will verify it and attach `req.user`.
4. **Token refresh** — when the access token expires, the frontend calls
   `POST /api/v1/auth/refresh`, which reads the httpOnly cookie and
   issues a new access token — the user never notices.
5. **Role-based access** — `restrictTo("ADMIN")` will be added to admin
   routes once a `role` field exists on the `User` model, ensuring only
   admins can hit `/api/v1/admin/*` endpoints.

## Why this design

- **bcrypt** for password hashing is a deliberately slow, salted hash —
  resistant to brute-force even if the database leaks.
- **Short-lived access + long-lived refresh** tokens limit the damage
  window if an access token is ever stolen, while still keeping users
  logged in for days without re-entering credentials.
- **httpOnly cookie for the refresh token** means client-side JavaScript
  (and therefore XSS attacks) can never read it directly.
