# Git Setup & Branch Strategy

## Initial commit instructions

```bash
cd 420clothing
git init
git add .
git commit -m "chore: scaffold project foundation (Phase 2)"

# Create the GitHub repo, then:
git branch -M main
git remote add origin https://github.com/<your-org>/420clothing.git
git push -u origin main
```

Both `frontend/.gitignore` and `backend/.gitignore` already exclude
`node_modules/`, build output, and `.env` files — double-check
`git status` before your first commit to make sure no real secrets were
accidentally created in a `.env` file (only `.env.example` should ever
be committed).

## Branch strategy

A simple, beginner-friendly trunk-based flow:

```
main                    ← always deployable; protected branch
 ├── feat/product-schema
 ├── feat/auth-endpoints
 ├── fix/cart-total-rounding
 └── chore/update-deps
```

**Rules:**

- `main` is always production-ready and protected (no direct pushes —
  require pull requests).
- Every change gets its own short-lived branch, named
  `type/short-description`:
  - `feat/...` — new functionality
  - `fix/...` — bug fixes
  - `chore/...` — tooling, dependencies, config
  - `docs/...` — documentation only
- Open a Pull Request into `main` — Vercel automatically builds a
  preview deployment for it.
- Squash-merge once approved, then delete the branch.

**Commit message convention** (Conventional Commits — keeps history
readable and enables automated changelogs later):

```
feat(auth): add login endpoint
fix(cart): correct tax calculation rounding
chore(deps): bump prisma to 5.20.0
docs(readme): add local setup instructions
```

## As the project grows

Once multiple people ship concurrently, consider adding a `develop`
branch (integration branch) between feature branches and `main`, with
`main` reserved for tagged releases. Not necessary at this stage — keep
the workflow as simple as the team size requires.
