# How the Frontend Talks to the Backend

## The short version

The Next.js frontend and the Express backend are **two separate
applications** running on two separate servers (and, in production, two
separate hosting platforms). They only ever communicate over HTTP, via
JSON, through the API.

```
Browser  ──renders──►  Next.js frontend (Vercel)
                             │
                             │  HTTPS requests (JSON)
                             ▼
                        Express backend (Railway)
                             │
                             │  SQL queries (via Prisma)
                             ▼
                         PostgreSQL database
```

## The connection point: `lib/api.ts`

Every HTTP call from the frontend goes through one shared Axios
instance:

```ts
// frontend/src/lib/api.ts
export const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL, // e.g. http://localhost:5000/api/v1
  withCredentials: true,                    // sends the httpOnly refresh-token cookie
});
```

Centralizing this means:
- The API's base URL lives in **one place** (an env variable), not
  hardcoded in dozens of components.
- Once auth exists, attaching the JWT to every request is a single
  interceptor added here — every existing call site automatically
  benefits.

## Request/response shape

The backend's `utils/apiResponse.ts` guarantees every endpoint responds
with the same JSON envelope:

```json
{ "success": true, "message": "...", "data": { } }
```

or on error:

```json
{ "success": false, "message": "...", "errors": { } }
```

The frontend's `types/index.ts` defines a matching `ApiResponse<T>`
type, so both sides agree on the contract even before real endpoints
exist.

## CORS — why cross-origin requests are allowed at all

Browsers block requests from one origin (`localhost:3000`) to another
(`localhost:5000`) unless the server explicitly allows it. The backend's
`config/cors.ts` whitelists exactly the frontend's URL
(`FRONTEND_URL` env variable) and allows credentials (cookies) to be
sent — nothing else is allowed to call the API from a browser.

## API versioning

All routes live under `/api/v1/...`. If the API needs breaking changes
later, a `/api/v2/...` can be introduced without breaking any client
still using v1 — this is why `routes/v1/` is its own folder rather than
routes being mounted directly at `/api/`.
