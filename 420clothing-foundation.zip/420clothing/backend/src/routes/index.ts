/**
 * routes/index.ts
 * ────────────────────────────────────────────────────────────
 * Root API router. Mounted at /api/v1 in app.ts. Aggregates every
 * versioned route module so app.ts only has ONE import to worry
 * about, and adding a new resource means editing this file only.
 */
import { Router } from "express";
import v1Routes from "./v1";

const router = Router();

router.use("/", v1Routes);

export default router;
