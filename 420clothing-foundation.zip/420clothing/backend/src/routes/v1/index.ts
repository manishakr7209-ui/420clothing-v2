/**
 * routes/v1/index.ts
 * ────────────────────────────────────────────────────────────
 * Aggregates all v1 resource routers. Each resource (auth, users,
 * products, ...) gets its own file — this keeps route files small
 * and lets each domain evolve independently.
 *
 * NOTE (Phase 2 scope): route files below are placeholders that
 * return 501 Not Implemented. Real handlers arrive with their
 * matching business logic in later phases.
 */
import { Router } from "express";
import authRoutes from "./auth.routes";
import userRoutes from "./user.routes";
import productRoutes from "./product.routes";
import orderRoutes from "./order.routes";

const router = Router();

router.use("/auth", authRoutes);
router.use("/users", userRoutes);
router.use("/products", productRoutes);
router.use("/orders", orderRoutes);

export default router;
