/**
 * routes/v1/user.routes.ts
 * PLACEHOLDER route file — defines the shape of the user API
 * surface without business logic yet (per Phase 2 scope).
 * Real handlers get wired up in user.controller.ts in a later phase.
 */
import { Router } from "express";

const router = Router();

router.all("*", (_req, res) => {
  res.status(501).json({
    success: false,
    message: "user routes are scaffolded but not implemented yet (coming in a later phase).",
  });
});

export default router;
