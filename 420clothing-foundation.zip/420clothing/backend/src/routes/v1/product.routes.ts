/**
 * routes/v1/product.routes.ts
 * PLACEHOLDER route file — defines the shape of the product API
 * surface without business logic yet (per Phase 2 scope).
 * Real handlers get wired up in product.controller.ts in a later phase.
 */
import { Router } from "express";

const router = Router();

router.all("*", (_req, res) => {
  res.status(501).json({
    success: false,
    message: "product routes are scaffolded but not implemented yet (coming in a later phase).",
  });
});

export default router;
