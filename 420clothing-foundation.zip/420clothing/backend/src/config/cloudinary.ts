/**
 * config/cloudinary.ts
 * Configures the Cloudinary SDK for product/user image uploads.
 * Actual upload logic will live in services/upload.service.ts (Phase 3+).
 */
import { v2 as cloudinary } from "cloudinary";
import { env } from "./env";

cloudinary.config({
  cloud_name: env.CLOUDINARY_CLOUD_NAME,
  api_key: env.CLOUDINARY_API_KEY,
  api_secret: env.CLOUDINARY_API_SECRET,
  secure: true,
});

export default cloudinary;
