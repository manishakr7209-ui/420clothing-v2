/**
 * config/database.ts
 * ────────────────────────────────────────────────────────────
 * Single shared Prisma Client instance (singleton pattern).
 * Prevents "too many connections" errors that happen when a new
 * PrismaClient is instantiated on every hot-reload in dev.
 */
import { PrismaClient } from "@prisma/client";

declare global {
  // eslint-disable-next-line no-var
  var prismaGlobal: PrismaClient | undefined;
}

export const prisma = global.prismaGlobal ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  global.prismaGlobal = prisma;
}
