/**
 * config/env.ts
 * ────────────────────────────────────────────────────────────
 * Validates and centralizes access to environment variables.
 * Import `env` anywhere instead of using `process.env` directly —
 * this guarantees required variables exist at startup (fail fast)
 * and gives full TypeScript autocomplete instead of `string | undefined`.
 */
import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: z.coerce.number().default(5000),
  API_VERSION: z.string().default("v1"),

  FRONTEND_URL: z.string().url(),
  BACKEND_URL: z.string().url(),

  DATABASE_URL: z.string().min(1, "DATABASE_URL is required"),

  JWT_ACCESS_SECRET: z.string().min(32, "JWT_ACCESS_SECRET must be at least 32 chars"),
  JWT_REFRESH_SECRET: z.string().min(32, "JWT_REFRESH_SECRET must be at least 32 chars"),
  JWT_ACCESS_EXPIRES_IN: z.string().default("15m"),
  JWT_REFRESH_EXPIRES_IN: z.string().default("7d"),
  BCRYPT_SALT_ROUNDS: z.coerce.number().default(12),

  CLOUDINARY_CLOUD_NAME: z.string().optional(),
  CLOUDINARY_API_KEY: z.string().optional(),
  CLOUDINARY_API_SECRET: z.string().optional(),
});

// Parsing throws (and crashes the server on boot) if required vars
// are missing — this is intentional. Better to fail at startup than
// to fail confusingly mid-request in production.
export const env = envSchema.parse(process.env);
