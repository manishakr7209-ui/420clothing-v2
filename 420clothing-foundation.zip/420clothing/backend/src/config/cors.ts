/**
 * config/cors.ts
 * Restricts API access to our own frontend (and localhost in dev).
 */
import { CorsOptions } from "cors";
import { env } from "./env";

export const corsOptions: CorsOptions = {
  origin: [env.FRONTEND_URL],
  credentials: true, // allow httpOnly cookies (refresh token) to be sent
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
};
