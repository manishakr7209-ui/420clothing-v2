# Validations

Zod schemas that describe the exact shape of valid request `body`/`query`/
`params` for each route. Used by `middleware/validate.middleware.ts` so
invalid requests are rejected with a 422 *before* they ever reach a
controller.

Example (future): `auth.validation.ts` exports `registerSchema`,
`loginSchema`.
