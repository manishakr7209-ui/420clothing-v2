/**
 * server.ts
 * ────────────────────────────────────────────────────────────
 * Entry point of the backend. Its ONLY job is to start the HTTP
 * server. All Express app configuration (middleware, routes)
 * lives in app.ts so that app.ts can be imported in tests
 * without actually binding to a port.
 */
import "dotenv/config";
import app from "./app";
import { logger } from "@utils/logger";
import { env } from "@config/env";

const PORT = env.PORT;

const server = app.listen(PORT, () => {
  logger.info(`🚀 420Clothing API running on http://localhost:${PORT}`);
  logger.info(`   Environment: ${env.NODE_ENV}`);
  logger.info(`   API base:    /api/${env.API_VERSION}`);
});

// Gracefully handle unexpected crashes instead of letting the
// process die silently mid-request in production.
process.on("unhandledRejection", (reason) => {
  logger.error("Unhandled Promise Rejection:", reason);
  server.close(() => process.exit(1));
});

process.on("uncaughtException", (error) => {
  logger.error("Uncaught Exception:", error);
  process.exit(1);
});
