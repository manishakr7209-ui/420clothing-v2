/**
 * utils/jwt.ts
 * Thin wrappers around jsonwebtoken. Actual sign/verify calls will
 * be used by the auth service — left as typed stubs for Phase 3
 * so the shape of the API is clear now without building auth yet.
 */
import jwt, { SignOptions } from "jsonwebtoken";
import { env } from "@config/env";

export interface JwtPayload {
  userId: string;
  role: "CUSTOMER" | "ADMIN";
}

export function signAccessToken(payload: JwtPayload): string {
  return jwt.sign(payload, env.JWT_ACCESS_SECRET, {
    expiresIn: env.JWT_ACCESS_EXPIRES_IN,
  } as SignOptions);
}

export function signRefreshToken(payload: JwtPayload): string {
  return jwt.sign(payload, env.JWT_REFRESH_SECRET, {
    expiresIn: env.JWT_REFRESH_EXPIRES_IN,
  } as SignOptions);
}

export function verifyAccessToken(token: string): JwtPayload {
  return jwt.verify(token, env.JWT_ACCESS_SECRET) as JwtPayload;
}

export function verifyRefreshToken(token: string): JwtPayload {
  return jwt.verify(token, env.JWT_REFRESH_SECRET) as JwtPayload;
}
