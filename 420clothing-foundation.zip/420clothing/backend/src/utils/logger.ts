/**
 * utils/logger.ts
 * ────────────────────────────────────────────────────────────
 * Centralized Winston logger. Use this instead of console.log
 * everywhere so logs are leveled, timestamped, and (in production)
 * easy to ship to a log aggregator (e.g. Railway logs, Logtail, Datadog).
 */
import winston from "winston";

const { combine, timestamp, printf, colorize, errors } = winston.format;

const logFormat = printf(({ level, message, timestamp, stack }) => {
  return `${timestamp} [${level}]: ${stack || message}`;
});

export const logger = winston.createLogger({
  level: process.env.NODE_ENV === "production" ? "info" : "debug",
  format: combine(errors({ stack: true }), timestamp(), logFormat),
  transports: [
    new winston.transports.Console({
      format: combine(colorize(), timestamp(), logFormat),
    }),
    // In production you'd also add file/remote transports here.
  ],
});

// Adapter so morgan (HTTP request logger) can pipe into winston.
export const stream = {
  write: (message: string) => logger.info(message.trim()),
};
