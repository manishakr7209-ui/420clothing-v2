/**
 * utils/password.ts
 * bcrypt helpers for hashing and comparing passwords.
 * Used by the (future) auth service — not wired to routes yet.
 */
import bcrypt from "bcrypt";
import { env } from "@config/env";

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, env.BCRYPT_SALT_ROUNDS);
}

export async function comparePassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}
