/**
 * utils/apiResponse.ts
 * Standardizes the JSON shape every endpoint returns, so the
 * frontend can rely on one consistent contract.
 */
import { Response } from "express";

export function sendSuccess<T>(res: Response, data: T, message = "Success", statusCode = 200) {
  return res.status(statusCode).json({ success: true, message, data });
}

export function sendError(res: Response, message = "Something went wrong", statusCode = 500, errors?: unknown) {
  return res.status(statusCode).json({ success: false, message, errors });
}
