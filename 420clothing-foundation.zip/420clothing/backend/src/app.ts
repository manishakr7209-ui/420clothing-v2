/**
 * app.ts
 * ────────────────────────────────────────────────────────────
 * Builds and configures the Express application:
 *   security middleware -> parsers -> logging -> routes -> error handling
 * Exported (not started) so it can be reused by server.ts and
 * by integration tests (supertest) without opening a real port.
 */
import express, { Application } from "express";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import cookieParser from "cookie-parser";
import morgan from "morgan";

import { env } from "@config/env";
import { corsOptions } from "@config/cors";
import { apiRateLimiter } from "@middleware/rateLimiter.middleware";
import { notFoundHandler } from "@middleware/notFound.middleware";
import { errorHandler } from "@middleware/errorHandler.middleware";
import { stream } from "@utils/logger";
import routes from "@routes/index";

const app: Application = express();

// ── Security ──────────────────────────────────────────────────
app.use(helmet());               // sets safe HTTP headers
app.use(cors(corsOptions));      // restricts which origins can call this API
app.use(apiRateLimiter);         // throttles abusive clients

// ── Parsers ───────────────────────────────────────────────────
app.use(express.json({ limit: "10kb" }));           // parse JSON bodies, capped to prevent abuse
app.use(express.urlencoded({ extended: true }));    // parse form bodies
app.use(cookieParser());                            // reads httpOnly refresh-token cookie
app.use(compression());                              // gzip responses

// ── Logging ───────────────────────────────────────────────────
app.use(morgan(env.NODE_ENV === "development" ? "dev" : "combined", { stream }));

// ── Health check (used by Railway/Vercel uptime checks) ────────
app.get("/health", (_req, res) => {
  res.status(200).json({ status: "ok", timestamp: new Date().toISOString() });
});

// ── Versioned API routes — everything lives under /api/v1 ──────
app.use(`/api/${env.API_VERSION}`, routes);

// ── 404 + centralized error handling (must be registered last) ─
app.use(notFoundHandler);
app.use(errorHandler);

export default app;
