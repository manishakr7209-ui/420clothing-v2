# Services

Services hold **business logic** — the actual rules of the application
("a user cannot check out with an empty cart", "an order total includes
tax + shipping", etc).

Services:
- Are called by controllers.
- Call repositories for any database access (never Prisma directly).
- Can call other services (e.g. `order.service.ts` calling `email.service.ts`).
- Contain no `req`/`res` — they are framework-agnostic and unit-testable
  in isolation.
