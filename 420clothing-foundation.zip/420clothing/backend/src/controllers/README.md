# Controllers

Controllers are the **HTTP layer only**. Their job:

1. Read the request (`req.body`, `req.params`, `req.query`).
2. Call a **service** to do the actual work.
3. Send the response with a consistent shape via `utils/apiResponse.ts`.

Controllers must **never** talk to Prisma/the database directly, and should
contain no business rules — that logic belongs in `services/`. This keeps
controllers thin, easy to test, and easy to reuse (e.g. same service called
from a controller and from a background job later).

Example (future): `auth.controller.ts` → calls `auth.service.ts` → which
calls `user.repository.ts`.
