/**
 * types/index.ts
 * Shared TypeScript types/interfaces used across the backend
 * (e.g. Express Request augmentation for req.user once auth exists).
 */
export {};

declare global {
  namespace Express {
    interface Request {
      // Populated by middleware/auth.middleware.ts once implemented
      user?: {
        userId: string;
        role: "CUSTOMER" | "ADMIN";
      };
    }
  }
}
