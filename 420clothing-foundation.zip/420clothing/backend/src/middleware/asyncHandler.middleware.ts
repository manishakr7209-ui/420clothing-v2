/**
 * middleware/asyncHandler.middleware.ts
 * Wraps async route/controller functions so any rejected Promise
 * is automatically forwarded to errorHandler — no repetitive
 * try/catch needed in every controller.
 *
 * Usage: router.get("/", asyncHandler(myController.list));
 */
import { NextFunction, Request, RequestHandler, Response } from "express";

export const asyncHandler =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>): RequestHandler =>
  (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
