/**
 * middleware/rateLimiter.middleware.ts
 * Throttles requests per IP to protect against brute-force and
 * scraping abuse. Applied globally in app.ts; stricter, dedicated
 * limiters (e.g. for /auth/login) can be added per-route later.
 */
import rateLimit from "express-rate-limit";
import { env } from "@config/env";

export const apiRateLimiter = rateLimit({
  windowMs: env.PORT ? 15 * 60 * 1000 : 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many requests, please try again later." },
});
