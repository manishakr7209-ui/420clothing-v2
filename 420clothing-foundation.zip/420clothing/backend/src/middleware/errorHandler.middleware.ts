/**
 * middleware/errorHandler.middleware.ts
 * ────────────────────────────────────────────────────────────
 * SINGLE place where every thrown error in the app ends up.
 * Controllers should just `throw new NotFoundError(...)` (or let
 * Prisma/validation errors bubble up) — never format error JSON
 * by hand inside a route.
 */
import { NextFunction, Request, Response } from "express";
import { ZodError } from "zod";
import { AppError } from "@errors/AppError";
import { logger } from "@utils/logger";
import { env } from "@config/env";

export function errorHandler(err: Error, req: Request, res: Response, _next: NextFunction) {
  // Known, "expected" errors (NotFoundError, BadRequestError, etc.)
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      success: false,
      message: err.message,
    });
  }

  // Validation errors thrown by Zod schemas (see /validations)
  if (err instanceof ZodError) {
    return res.status(422).json({
      success: false,
      message: "Validation failed",
      errors: err.flatten().fieldErrors,
    });
  }

  // Anything else is an unexpected bug — log the full stack and
  // never leak internal details to the client in production.
  logger.error(`${req.method} ${req.originalUrl} — ${err.message}`, { stack: err.stack });

  return res.status(500).json({
    success: false,
    message: env.NODE_ENV === "production" ? "Internal server error" : err.message,
    ...(env.NODE_ENV !== "production" && { stack: err.stack }),
  });
}
