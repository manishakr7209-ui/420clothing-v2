/**
 * middleware/auth.middleware.ts
 * ────────────────────────────────────────────────────────────
 * PLACEHOLDER — structure only, per Phase 2 scope ("do not
 * generate authentication yet"). This shows WHERE auth will plug
 * in (protect / restrictTo) so routes can already be wired to it
 * in Phase 3 without restructuring the app.
 */
import { NextFunction, Request, Response } from "express";

// Will attach the decoded JWT payload to req.user once implemented.
export function protect(_req: Request, _res: Response, next: NextFunction) {
  // TODO (Phase 3): verify access token from Authorization header,
  // attach user to req.user, throw UnauthorizedError if invalid.
  next();
}

// Will restrict a route to specific roles, e.g. restrictTo("ADMIN")
export function restrictTo(..._roles: string[]) {
  return (_req: Request, _res: Response, next: NextFunction) => {
    // TODO (Phase 3): check req.user.role against allowed roles.
    next();
  };
}
