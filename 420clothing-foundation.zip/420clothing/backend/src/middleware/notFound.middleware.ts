/**
 * middleware/notFound.middleware.ts
 * Catches requests to routes that don't exist and forwards a
 * clean 404 instead of Express's default HTML error page.
 */
import { NextFunction, Request, Response } from "express";
import { NotFoundError } from "@errors/AppError";

export function notFoundHandler(req: Request, _res: Response, next: NextFunction) {
  next(new NotFoundError(`Route not found: ${req.method} ${req.originalUrl}`));
}
