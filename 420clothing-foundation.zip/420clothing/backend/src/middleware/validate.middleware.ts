/**
 * middleware/validate.middleware.ts
 * Runs a Zod schema against req.body/query/params before the
 * request reaches a controller. Keeps validation declarative and
 * out of controller logic. See /validations for schema examples.
 */
import { NextFunction, Request, Response } from "express";
import { AnyZodObject } from "zod";

export const validate =
  (schema: AnyZodObject) => (req: Request, _res: Response, next: NextFunction) => {
    schema.parse({ body: req.body, query: req.query, params: req.params });
    next();
  };
