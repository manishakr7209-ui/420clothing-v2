# Repositories (Repository Pattern)

Repositories are the **only** place in the codebase allowed to import
`prisma` and run queries. Everything else talks to data through a
repository function.

Why this pattern:
- If we ever swap PostgreSQL/Prisma for something else, only this folder
  changes.
- Makes services easy to unit test — mock the repository, not the database.
- Keeps raw queries out of business logic, and business logic out of
  queries.

Example (future): `user.repository.ts` exports `findByEmail()`,
`createUser()`, etc. — plain functions returning typed Prisma models.
