// Shared code-formatting rules — keeps diffs clean across the team
export default {
  semi: true,
  singleQuote: false,
  trailingComma: "es5",
  tabWidth: 2,
  printWidth: 100,
  arrowParens: "always",
  endOfLine: "lf",
};
